from django.db import models
from django.contrib.auth.models import User
from django.utils.translation import gettext_lazy as _
from phonenumber_field.modelfields import PhoneNumberField

# Create your models here.
class coach(models.Model):
    User = models.OneToOneField(User, verbose_name=_("المستخدم"), on_delete=models.CASCADE)
    CName = models.CharField(_("اسم المدرب"), max_length=50)
    CPhone = PhoneNumberField(_("رقم المدرب"), blank=True)
    Cemail = models.EmailField(_("بريد المدرب"), max_length=254)

    class Meta:
        db_table = ''
        managed = True
        verbose_name = 'المدرب'
        verbose_name_plural = 'المدربين'
    def __str__(self):
        return self.CName
    