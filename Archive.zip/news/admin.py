from django.contrib import admin
from news.models import news
# Register your models here.

admin.site.register(news)