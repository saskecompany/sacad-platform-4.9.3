from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.views.generic import DetailView
from students.models import student
from home.models import Lessons, catgory
from .models import news
from tasks.models import exam
# Create your views here.

class newsDetailview(DetailView):
    model = news
    template_name='newsdetail.html'
    context_object_name="news"


@login_required
def newslistview(request):
    cats = catgory.objects.all()
    newslist = news.objects.all()
    examlist = exam.objects.all().order_by("publishAt")[:3]
    if not request.user.is_staff:
        if not student.objects.get(sinit = request.user).Sstatus:
            return redirect("/coaches")
        else:
            cuser = student.objects.get(sinit=request.user)
            lessons = Lessons.objects.all()[:5]
    if request.user.is_staff:
        lessons = Lessons.objects.all()[:5]
    context={
        "news":newslist,
        "all" : lessons,
        "exams": examlist,
        "cats":cats
    }
    return render(request, "index.html", context)

