from django.contrib import admin
from .models import Live
# Register your models here.
admin.site.register(Live)